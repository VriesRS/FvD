# Procesverslag
Markdown is een simpele manier om HTML te schrijven.  
Markdown cheat cheet: [Hulp bij het schrijven van Markdown](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet).

Nb. De standaardstructuur en de spartaanse opmaak van de README.md zijn helemaal prima. Het gaat om de inhoud van je procesverslag. Besteedt de tijd voor pracht en praal aan je website.

Nb. Door *open* toe te voegen aan een *details* element kun je deze standaard open zetten. Fijn om dat steeds voor de relevante stuk(ken) te doen.





## Jij

<details open>
  <summary>uitwerken voor kick-off werkgroep</summary>

  ### Auteur:
  Ryan de Vries

  #### Je startniveau:
  Rood

  #### Je focus:
  surface plane
 
</details>





## Je website

<details open>
  <summary>uitwerken voor kick-off werkgroep</summary>

  ### Je opdracht:
  (https://www.marvel.com/)

  #### Screenshot(s) van de eerste pagina (small screen): 
  hier de naam van de pagina  
  <img src="readme-images/dummy-plaatje.jpg" width="375px" alt="omschrijving van de pagina">

  #### Screenshot(s) van de tweede pagina (small screen):
  hier de naam van de pagina  
  <img src="readme-images/dummy-plaatje.jpg" width="375px" alt="omschrijving van de pagina">
 
</details>



## Toegankelijkheidstest 1/2 (week 1)

<details>
  <summary>uitwerken na test in 1e werkgroep</summary>

  ### Bevindingen
  Lijst met je bevindingen die in de test naar voren kwamen:

  #### Screenreader
  Hier korte omschrijving (met indien nodig afbeeldingen)
De screenreader las gelijk de complete pagina voor. Je merkte geen verschil tussen headings en knoppen met links. De nav bar werdt niet voorgelezen.
  
  
  Hier een omschrijving van hoe het opgelost kan worden (met indien nodig afbeeldingen)
Verschil creëren zodat je weet wanneer je een link hebt. Dingen zoals de nav bar wat meer naar voor brengen.
  

  #### Muis en Toetsenbord 
  Hier korte omschrijving (met indien nodig afbeeldingen)
  
  Je kon lang niet door alles heen navigeren de toetsenbord manier slaat knoppen over die je wel kan zien. Ook is er geen duidelijke aanwijzing van waar je focus zit en op welk blokje je bent.

  Hier een omschrijving van hoe het opgelost kan worden (met indien nodig afbeeldingen)
  
  een duidelijke focus state te maken zodat je weet waar je bent en er moet de mogelijk heid komen om ook over alle knoppen heen te kunnnen navigeren


  #### Motoriek (shocks, elastiekjes)
  Met elastiekjes en dus minder makkelijk te gebruiken vingers is het wel te doen het is alleen lastig te gebruiken als je je telefoon in de zelfde hand houdt.
  
  De Shocks in je armen zijn erg irritant je begint hierdoor erg te bewegen hierdoor is het scherm lastig te lezen. 
  
  de ballon hooghoudt oefening is wel irritant om dan te focussen waar je was gebleven met lezen in een langere tekst, zeker met kleinere letters in grotere stukken tekst.

  Hier een omschrijving van hoe het opgelost kan worden (met indien nodig afbeeldingen)

  Lastig op te lossen via de site. Een screenreader helpt al met het voorlezen tegen het shacken, Grotere leters en knoppen kunnen het makkelijker maken om iets te lezen en of gebruiken.
  
  je zou het focus probleem kunnen oplossen doormiddel van disclosive progression. Grotere letters maakt het makelijker terug vinden. En bijvoorbeeld prikkels die de aandacht lokken naar het scherm. Bijvoorbeeld bewegingen.
  
  
  #### Visueel (brillen, contrast, kleurenblind, dark/light). 
  Hier korte omschrijving (met indien nodig afbeeldingen)

  met bril getest dat het wazig werd er ontstond een soort glow waardoor felle kleuren nog feller werden en de wegvielen tegen het wit.
  
  Kleurenblind merkte je niet veel tegenslag de site is wel minder vrolijk aan kleuren.
  
  stip in het midden is de tekst amper tot niet te lezen
  
  Hier een omschrijving van hoe het opgelost kan worden (met indien nodig afbeeldingen).
  

  Beter contrast bij de tekst in kleur. 
  
  Grotere letters
  
</details>



## Breakdownschets (week 1)

<details>
  <summary>uitwerken na afloop 2e werkgroep</summary>

  ### de hele pagina: 
  <img src="readme-images/dummy-plaatje.jpg" width="375px" alt="breakdown van de hele pagina">

  ### dynamisch deel (bijv menu): 
  <img src="readme-images/dummy-plaatje.jpg" width="375px" alt="breakdown van een dynamisch deel">

  ### wellicht nog een dynamisch deel (bijv filter): 
  <img src="readme-images/dummy-plaatje.jpg" width="375px" alt="breakdown van nog een dynamisch deel">

</details>





## Voortgang 1 (week 2)

<details>
  <summary>uitwerken voor 1e voortgang</summary>

  ### Stand van zaken
  hier dit ging goed & dit was lastig (neem ook screenshots op van delen van je website en code)
  
  Het was voor mij lastig om niet naar de html te kijken van de site die ik namaak. Ik wil te graag dan precies het zelfde doen wat echt alles behalve       goed is. Waardoor ik zo laat opgang kwam van het schrijven van mijn site. Verder heb ik niet echt dingen waar ik tegen aan liep. Ik kom tot nu toe goed door de code heen met wat ik wil maken. Soms ik moet wel even wat extra opdrachten bij gaan maken van positionering zodat me dat ook wat makkelijker afgaan. Ik heb voor de eerste voortgang al wat geleerd van onderandere de linear-gradient en grid.


  ### Agenda voor meeting
  samen met je groepje opstellen

  | student 1      | student 2          | student 3    | student 4        |
  | Bente          | Ryan               | Lisa         | Tijn             |
  | HTML accesible | Voortgang          | voortgang    | Javascript.      |
  | Maken.         | dit als er tijd is | nog een punt |                  |
  |                |                    |              |                  |


  ### Verslag van meeting
  hier na afloop snel de uitkomsten van de meeting vastleggen

  - punt 1
  - punt 2
  - nog een punt
  - ...

</details>





## Voortgang 2 (week 3)

<details>
  <summary>uitwerken voor 2e voortgang</summary>

  ### Stand van zaken
  hier dit ging goed & dit was lastig (neem ook screenshots op van delen van je website en code)


  ### Agenda voor meeting
  samen met je groepje opstellen

  | student 1      | student 2          | student 3    | student 4        |
  | ---            | ---                | ---          | ---              |
  | dit bespreken  | en dit             | en ik dit    | en dan ik dat    |
  | en dat ook nog | dit als er tijd is | nog een punt | dit wil ik zeker |
  | ...            | ...                | ...          | ...              |


  ### Verslag van meeting
  hier na afloop snel de uitkomsten van de meeting vastleggen

  - punt 1
  - punt 2
  - nog een punt
- ...

</details>





## Toegankelijkheidstest 2/2 (week 4)

<details>
  <summary>uitwerken na test in 8e werkgroep</summary>

  ### Bevindingen
  Lijst met je bevindingen die in de test naar voren kwamen (geef ook aan wat er verbeterd is):

  #### Screenreader
  Hier korte omschrijving (met indien nodig afbeeldingen)

  Hier een omschrijving van hoe het opgelost kan worden (met indien nodig afbeeldingen)


  #### Muis en Toetsenbord 
  Hier korte omschrijving (met indien nodig afbeeldingen)

  Hier een omschrijving van hoe het opgelost kan worden (met indien nodig afbeeldingen)


  #### Motoriek (shocks, elastiekjes)
  Hier korte omschrijving (met indien nodig afbeeldingen)

  Hier een omschrijving van hoe het opgelost kan worden (met indien nodig afbeeldingen)


  #### Visueel (brillen, contrast, kleurenblind, dark/light). 
  Hier korte omschrijving (met indien nodig afbeeldingen)

  Hier een omschrijving van hoe het opgelost kan worden (met indien nodig afbeeldingen)

</details>





## Voortgang 3 (week 4)

<details>
  <summary>uitwerken voor 3e voortgang</summary>

  ### Stand van zaken
  hier dit ging goed & dit was lastig (neem ook screenshots op van delen van je website en code)


  ### Agenda voor meeting
  samen met je groepje opstellen

  | student 1      | student 2          | student 3    | student 4        |
  | ---            | ---                | ---          | ---              |
  | dit bespreken  | en dit             | en ik dit    | en dan ik dat    |
  | en dat ook nog | dit als er tijd is | nog een punt | dit wil ik zeker |
  | ...            | ...                | ...          | ...              |


  ### Verslag van meeting
  hier na afloop snel de uitkomsten van de meeting vastleggen

  - punt 1
  - punt 2
  - nog een punt
  - ...

</details>





## Eindgesprek (week 5)

<details>
  <summary>uitwerken voor eindgesprek</summary>

  ### Je uitkomst - karakteristiek screenshots:
  <img src="readme-images/dummy-plaatje.jpg" width="375px" alt="uitomst opdracht 1">


  ### Dit ging goed/Heb ik geleerd: 
  Korte omschrijving met plaatjes

  <img src="readme-images/dummy-plaatje.jpg" width="375px" alt="top">


  ### Dit was lastig/Is niet gelukt:
  Korte omschrijving met plaatjes

  <img src="readme-images/dummy-plaatje.jpg" width="375px" alt="bummer">
</details>





## Bronnenlijst

<details open>
  <summary>continu bijhouden terwijl je werkt</summary>

  Nb. Wees specifiek ('css-tricks' als bron is bijv. niet specifiek genoeg).

  1. bron 1
  2. bron 2
  3. ...

</details>
